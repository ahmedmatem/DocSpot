import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-departments',
  imports: [],
  templateUrl: './departments.component.html',
  styleUrl: './departments.component.css'
})
export class DepartmentsComponent {

}
