import { Component } from '@angular/core';

@Component({
  selector: 'app-doctors',
  imports: [],
  templateUrl: './doctors.component.html',
  styleUrl: './doctors.component.css'
})
export class DoctorsComponent {

}
