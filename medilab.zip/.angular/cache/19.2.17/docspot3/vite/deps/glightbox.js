import {
  __commonJS
} from "./chunk-3OV72XIM.js";

// node_modules/glightbox/dist/js/glightbox.min.js
var require_glightbox_min = __commonJS({
  "node_modules/glightbox/dist/js/glightbox.min.js"(exports, module) {
    !function(e, t) {
      "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = e || self).GLightbox = t();
    }(exports, function() {
      "use strict";
      function e(e2, t2) {
        if (!(e2 instanceof t2)) throw new TypeError("Cannot call a class as a function");
      }
      function t(e2, t2) {
        for (var i2 = 0; i2 < t2.length; i2++) {
          var s2 = t2[i2];
          s2.enumerable = s2.enumerable || false, s2.configurable = true, "value" in s2 && (s2.writable = true), Object.defineProperty(e2, n(s2.key), s2);
        }
      }
      function i(e2, i2, n2) {
        return i2 && t(e2.prototype, i2), n2 && t(e2, n2), Object.defineProperty(e2, "prototype", {
          writable: false
        }), e2;
      }
      function n(e2) {
        var t2 = function(e3, t3) {
          if ("object" != typeof e3 || !e3) return e3;
          var i2 = e3[Symbol.toPrimitive];
          if (void 0 !== i2) {
            var n2 = i2.call(e3, t3 || "default");
            if ("object" != typeof n2) return n2;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return ("string" === t3 ? String : Number)(e3);
        }(e2, "string");
        return "symbol" == typeof t2 ? t2 : t2 + "";
      }
      function s(e2) {
        return (s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e3) {
          return typeof e3;
        } : function(e3) {
          return e3 && "function" == typeof Symbol && e3.constructor === Symbol && e3 !== Symbol.prototype ? "symbol" : typeof e3;
        })(e2);
      }
      var l = Date.now();
      function o() {
        var e2 = {}, t2 = true, i2 = 0, n2 = arguments.length;
        "[object Boolean]" === Object.prototype.toString.call(arguments[0]) && (t2 = arguments[0], i2++);
        for (var s2 = function(i3) {
          for (var n3 in i3) Object.prototype.hasOwnProperty.call(i3, n3) && (t2 && "[object Object]" === Object.prototype.toString.call(i3[n3]) ? e2[n3] = o(true, e2[n3], i3[n3]) : e2[n3] = i3[n3]);
        }; i2 < n2; i2++) {
          var l2 = arguments[i2];
          s2(l2);
        }
        return e2;
      }
      function r(e2, t2) {
        if ((E(e2) || e2 === window || e2 === document) && (e2 = [e2]), L(e2) || I(e2) || (e2 = [e2]), 0 != M(e2)) {
          if (L(e2) && !I(e2)) for (var i2 = e2.length, n2 = 0; n2 < i2 && false !== t2.call(e2[n2], e2[n2], n2, e2); n2++) ;
          else if (I(e2)) {
            for (var s2 in e2) if (P(e2, s2) && false === t2.call(e2[s2], e2[s2], s2, e2)) break;
          }
        }
      }
      function a(e2) {
        var t2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, i2 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, n2 = e2[l] = e2[l] || [], s2 = {
          all: n2,
          evt: null,
          found: null
        };
        return t2 && i2 && M(n2) > 0 && r(n2, function(e3, n3) {
          if (e3.eventName == t2 && e3.fn.toString() == i2.toString()) return s2.found = true, s2.evt = n3, false;
        }), s2;
      }
      function h(e2) {
        var t2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, i2 = t2.onElement, n2 = t2.withCallback, s2 = t2.avoidDuplicate, l2 = void 0 === s2 || s2, o2 = t2.once, h2 = void 0 !== o2 && o2, d2 = t2.useCapture, c2 = void 0 !== d2 && d2, u2 = arguments.length > 2 ? arguments[2] : void 0, g2 = i2 || [];
        function v2(e3) {
          C(n2) && n2.call(u2, e3, this), h2 && v2.destroy();
        }
        return k(g2) && (g2 = document.querySelectorAll(g2)), v2.destroy = function() {
          r(g2, function(t3) {
            var i3 = a(t3, e2, v2);
            i3.found && i3.all.splice(i3.evt, 1), t3.removeEventListener && t3.removeEventListener(e2, v2, c2);
          });
        }, r(g2, function(t3) {
          var i3 = a(t3, e2, v2);
          (t3.addEventListener && l2 && !i3.found || !l2) && (t3.addEventListener(e2, v2, c2), i3.all.push({
            eventName: e2,
            fn: v2
          }));
        }), v2;
      }
      function d(e2, t2) {
        r(t2.split(" "), function(t3) {
          return e2.classList.add(t3);
        });
      }
      function c(e2, t2) {
        r(t2.split(" "), function(t3) {
          return e2.classList.remove(t3);
        });
      }
      function u(e2, t2) {
        return e2.classList.contains(t2);
      }
      function g(e2, t2) {
        for (; e2 !== document.body; ) {
          if (!(e2 = e2.parentElement)) return false;
          if ("function" == typeof e2.matches ? e2.matches(t2) : e2.msMatchesSelector(t2)) return e2;
        }
      }
      function v(e2) {
        var t2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", i2 = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (!e2 || "" === t2) return false;
        if ("none" === t2) return C(i2) && i2(), false;
        var n2 = b(), s2 = t2.split(" ");
        r(s2, function(t3) {
          d(e2, "g" + t3);
        }), h(n2, {
          onElement: e2,
          avoidDuplicate: false,
          once: true,
          withCallback: function(e3, t3) {
            r(s2, function(e4) {
              c(t3, "g" + e4);
            }), C(i2) && i2();
          }
        });
      }
      function f(e2) {
        var t2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        if ("" === t2) return e2.style.webkitTransform = "", e2.style.MozTransform = "", e2.style.msTransform = "", e2.style.OTransform = "", e2.style.transform = "", false;
        e2.style.webkitTransform = t2, e2.style.MozTransform = t2, e2.style.msTransform = t2, e2.style.OTransform = t2, e2.style.transform = t2;
      }
      function p(e2) {
        e2.style.display = "block";
      }
      function m(e2) {
        e2.style.display = "none";
      }
      function y(e2) {
        var t2 = document.createDocumentFragment(), i2 = document.createElement("div");
        for (i2.innerHTML = e2; i2.firstChild; ) t2.appendChild(i2.firstChild);
        return t2;
      }
      function x() {
        return {
          width: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
          height: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
        };
      }
      function b() {
        var e2, t2 = document.createElement("fakeelement"), i2 = {
          animation: "animationend",
          OAnimation: "oAnimationEnd",
          MozAnimation: "animationend",
          WebkitAnimation: "webkitAnimationEnd"
        };
        for (e2 in i2) if (void 0 !== t2.style[e2]) return i2[e2];
      }
      function S(e2, t2, i2, n2) {
        if (e2()) t2();
        else {
          var s2;
          i2 || (i2 = 100);
          var l2 = setInterval(function() {
            e2() && (clearInterval(l2), s2 && clearTimeout(s2), t2());
          }, i2);
          n2 && (s2 = setTimeout(function() {
            clearInterval(l2);
          }, n2));
        }
      }
      function w(e2, t2, i2) {
        if (O(e2)) console.error("Inject assets error");
        else if (C(t2) && (i2 = t2, t2 = false), k(t2) && t2 in window) C(i2) && i2();
        else {
          var n2;
          if (-1 !== e2.indexOf(".css")) {
            if ((n2 = document.querySelectorAll('link[href="' + e2 + '"]')) && n2.length > 0) return void (C(i2) && i2());
            var s2 = document.getElementsByTagName("head")[0], l2 = s2.querySelectorAll('link[rel="stylesheet"]'), o2 = document.createElement("link");
            return o2.rel = "stylesheet", o2.type = "text/css", o2.href = e2, o2.media = "all", l2 ? s2.insertBefore(o2, l2[0]) : s2.appendChild(o2), void (C(i2) && i2());
          }
          if ((n2 = document.querySelectorAll('script[src="' + e2 + '"]')) && n2.length > 0) {
            if (C(i2)) {
              if (k(t2)) return S(function() {
                return void 0 !== window[t2];
              }, function() {
                i2();
              }), false;
              i2();
            }
          } else {
            var r2 = document.createElement("script");
            r2.type = "text/javascript", r2.src = e2, r2.onload = function() {
              if (C(i2)) {
                if (k(t2)) return S(function() {
                  return void 0 !== window[t2];
                }, function() {
                  i2();
                }), false;
                i2();
              }
            }, document.body.appendChild(r2);
          }
        }
      }
      function T() {
        return "navigator" in window && window.navigator.userAgent.match(/(iPad)|(iPhone)|(iPod)|(Android)|(PlayBook)|(BB10)|(BlackBerry)|(Opera Mini)|(IEMobile)|(webOS)|(MeeGo)/i);
      }
      function C(e2) {
        return "function" == typeof e2;
      }
      function k(e2) {
        return "string" == typeof e2;
      }
      function E(e2) {
        return !(!e2 || !e2.nodeType || 1 != e2.nodeType);
      }
      function A(e2) {
        return Array.isArray(e2);
      }
      function L(e2) {
        return e2 && e2.length && isFinite(e2.length);
      }
      function I(e2) {
        return "object" === s(e2) && null != e2 && !C(e2) && !A(e2);
      }
      function O(e2) {
        return null == e2;
      }
      function P(e2, t2) {
        return null !== e2 && hasOwnProperty.call(e2, t2);
      }
      function M(e2) {
        if (I(e2)) {
          if (e2.keys) return e2.keys().length;
          var t2 = 0;
          for (var i2 in e2) P(e2, i2) && t2++;
          return t2;
        }
        return e2.length;
      }
      function z(e2) {
        return !isNaN(parseFloat(e2)) && isFinite(e2);
      }
      function X() {
        var e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1, t2 = document.querySelectorAll(".gbtn[data-taborder]:not(.disabled)");
        if (!t2.length) return false;
        if (1 == t2.length) return t2[0];
        "string" == typeof e2 && (e2 = parseInt(e2));
        var i2 = [];
        r(t2, function(e3) {
          i2.push(e3.getAttribute("data-taborder"));
        });
        var n2 = Math.max.apply(Math, i2.map(function(e3) {
          return parseInt(e3);
        })), s2 = e2 < 0 ? 1 : e2 + 1;
        s2 > n2 && (s2 = "1");
        var l2 = i2.filter(function(e3) {
          return e3 >= parseInt(s2);
        }), o2 = l2.sort()[0];
        return document.querySelector('.gbtn[data-taborder="'.concat(o2, '"]'));
      }
      function Y(e2) {
        if (e2.events.hasOwnProperty("keyboard")) return false;
        e2.events.keyboard = h("keydown", {
          onElement: window,
          withCallback: function(t2, i2) {
            var n2 = (t2 = t2 || window.event).keyCode;
            if (9 == n2) {
              var s2 = document.querySelector(".gbtn.focused");
              if (!s2) {
                var l2 = !(!document.activeElement || !document.activeElement.nodeName) && document.activeElement.nodeName.toLocaleLowerCase();
                if ("input" == l2 || "textarea" == l2 || "button" == l2) return;
              }
              t2.preventDefault();
              var o2 = document.querySelectorAll(".gbtn[data-taborder]");
              if (!o2 || o2.length <= 0) return;
              if (!s2) {
                var r2 = X();
                return void (r2 && (r2.focus(), d(r2, "focused")));
              }
              var a2 = X(s2.getAttribute("data-taborder"));
              c(s2, "focused"), a2 && (a2.focus(), d(a2, "focused"));
            }
            39 == n2 && e2.nextSlide(), 37 == n2 && e2.prevSlide(), 27 == n2 && e2.close();
          }
        });
      }
      var q = i(function t2(i2, n2) {
        var s2 = this, l2 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        if (e(this, t2), this.img = i2, this.slide = n2, this.onclose = l2, this.img.setZoomEvents) return false;
        this.active = false, this.zoomedIn = false, this.dragging = false, this.currentX = null, this.currentY = null, this.initialX = null, this.initialY = null, this.xOffset = 0, this.yOffset = 0, this.img.addEventListener("mousedown", function(e2) {
          return s2.dragStart(e2);
        }, false), this.img.addEventListener("mouseup", function(e2) {
          return s2.dragEnd(e2);
        }, false), this.img.addEventListener("mousemove", function(e2) {
          return s2.drag(e2);
        }, false), this.img.addEventListener("click", function(e2) {
          return s2.slide.classList.contains("dragging-nav") ? (s2.zoomOut(), false) : s2.zoomedIn ? void (s2.zoomedIn && !s2.dragging && s2.zoomOut()) : s2.zoomIn();
        }, false), this.img.setZoomEvents = true;
      }, [{
        key: "zoomIn",
        value: function() {
          var e2 = this.widowWidth();
          if (!(this.zoomedIn || e2 <= 768)) {
            var t2 = this.img;
            if (t2.setAttribute("data-style", t2.getAttribute("style")), t2.style.maxWidth = t2.naturalWidth + "px", t2.style.maxHeight = t2.naturalHeight + "px", t2.naturalWidth > e2) {
              var i2 = e2 / 2 - t2.naturalWidth / 2;
              this.setTranslate(this.img.parentNode, i2, 0);
            }
            this.slide.classList.add("zoomed"), this.zoomedIn = true;
          }
        }
      }, {
        key: "zoomOut",
        value: function() {
          this.img.parentNode.setAttribute("style", ""), this.img.setAttribute("style", this.img.getAttribute("data-style")), this.slide.classList.remove("zoomed"), this.zoomedIn = false, this.currentX = null, this.currentY = null, this.initialX = null, this.initialY = null, this.xOffset = 0, this.yOffset = 0, this.onclose && "function" == typeof this.onclose && this.onclose();
        }
      }, {
        key: "dragStart",
        value: function(e2) {
          e2.preventDefault(), this.zoomedIn ? ("touchstart" === e2.type ? (this.initialX = e2.touches[0].clientX - this.xOffset, this.initialY = e2.touches[0].clientY - this.yOffset) : (this.initialX = e2.clientX - this.xOffset, this.initialY = e2.clientY - this.yOffset), e2.target === this.img && (this.active = true, this.img.classList.add("dragging"))) : this.active = false;
        }
      }, {
        key: "dragEnd",
        value: function(e2) {
          var t2 = this;
          e2.preventDefault(), this.initialX = this.currentX, this.initialY = this.currentY, this.active = false, setTimeout(function() {
            t2.dragging = false, t2.img.isDragging = false, t2.img.classList.remove("dragging");
          }, 100);
        }
      }, {
        key: "drag",
        value: function(e2) {
          this.active && (e2.preventDefault(), "touchmove" === e2.type ? (this.currentX = e2.touches[0].clientX - this.initialX, this.currentY = e2.touches[0].clientY - this.initialY) : (this.currentX = e2.clientX - this.initialX, this.currentY = e2.clientY - this.initialY), this.xOffset = this.currentX, this.yOffset = this.currentY, this.img.isDragging = true, this.dragging = true, this.setTranslate(this.img, this.currentX, this.currentY));
        }
      }, {
        key: "onMove",
        value: function(e2) {
          if (this.zoomedIn) {
            var t2 = e2.clientX - this.img.naturalWidth / 2, i2 = e2.clientY - this.img.naturalHeight / 2;
            this.setTranslate(this.img, t2, i2);
          }
        }
      }, {
        key: "setTranslate",
        value: function(e2, t2, i2) {
          e2.style.transform = "translate3d(" + t2 + "px, " + i2 + "px, 0)";
        }
      }, {
        key: "widowWidth",
        value: function() {
          return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        }
      }]), N = i(function t2() {
        var i2 = this, n2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        e(this, t2);
        var s2 = n2.dragEl, l2 = n2.toleranceX, o2 = void 0 === l2 ? 40 : l2, r2 = n2.toleranceY, a2 = void 0 === r2 ? 65 : r2, h2 = n2.slide, d2 = void 0 === h2 ? null : h2, c2 = n2.instance, u2 = void 0 === c2 ? null : c2;
        this.el = s2, this.active = false, this.dragging = false, this.currentX = null, this.currentY = null, this.initialX = null, this.initialY = null, this.xOffset = 0, this.yOffset = 0, this.direction = null, this.lastDirection = null, this.toleranceX = o2, this.toleranceY = a2, this.toleranceReached = false, this.dragContainer = this.el, this.slide = d2, this.instance = u2, this.el.addEventListener("mousedown", function(e2) {
          return i2.dragStart(e2);
        }, false), this.el.addEventListener("mouseup", function(e2) {
          return i2.dragEnd(e2);
        }, false), this.el.addEventListener("mousemove", function(e2) {
          return i2.drag(e2);
        }, false);
      }, [{
        key: "dragStart",
        value: function(e2) {
          if (this.slide.classList.contains("zoomed")) this.active = false;
          else {
            "touchstart" === e2.type ? (this.initialX = e2.touches[0].clientX - this.xOffset, this.initialY = e2.touches[0].clientY - this.yOffset) : (this.initialX = e2.clientX - this.xOffset, this.initialY = e2.clientY - this.yOffset);
            var t2 = e2.target.nodeName.toLowerCase();
            e2.target.classList.contains("nodrag") || g(e2.target, ".nodrag") || -1 !== ["input", "select", "textarea", "button", "a"].indexOf(t2) ? this.active = false : (e2.preventDefault(), (e2.target === this.el || "img" !== t2 && g(e2.target, ".gslide-inline")) && (this.active = true, this.el.classList.add("dragging"), this.dragContainer = g(e2.target, ".ginner-container")));
          }
        }
      }, {
        key: "dragEnd",
        value: function(e2) {
          var t2 = this;
          e2 && e2.preventDefault(), this.initialX = 0, this.initialY = 0, this.currentX = null, this.currentY = null, this.initialX = null, this.initialY = null, this.xOffset = 0, this.yOffset = 0, this.active = false, this.doSlideChange && (this.instance.preventOutsideClick = true, "right" == this.doSlideChange && this.instance.prevSlide(), "left" == this.doSlideChange && this.instance.nextSlide()), this.doSlideClose && this.instance.close(), this.toleranceReached || this.setTranslate(this.dragContainer, 0, 0, true), setTimeout(function() {
            t2.instance.preventOutsideClick = false, t2.toleranceReached = false, t2.lastDirection = null, t2.dragging = false, t2.el.isDragging = false, t2.el.classList.remove("dragging"), t2.slide.classList.remove("dragging-nav"), t2.dragContainer.style.transform = "", t2.dragContainer.style.transition = "";
          }, 100);
        }
      }, {
        key: "drag",
        value: function(e2) {
          if (this.active) {
            e2.preventDefault(), this.slide.classList.add("dragging-nav"), "touchmove" === e2.type ? (this.currentX = e2.touches[0].clientX - this.initialX, this.currentY = e2.touches[0].clientY - this.initialY) : (this.currentX = e2.clientX - this.initialX, this.currentY = e2.clientY - this.initialY), this.xOffset = this.currentX, this.yOffset = this.currentY, this.el.isDragging = true, this.dragging = true, this.doSlideChange = false, this.doSlideClose = false;
            var t2 = Math.abs(this.currentX), i2 = Math.abs(this.currentY);
            if (t2 > 0 && t2 >= Math.abs(this.currentY) && (!this.lastDirection || "x" == this.lastDirection)) {
              this.yOffset = 0, this.lastDirection = "x", this.setTranslate(this.dragContainer, this.currentX, 0);
              var n2 = this.shouldChange();
              if (!this.instance.settings.dragAutoSnap && n2 && (this.doSlideChange = n2), this.instance.settings.dragAutoSnap && n2) return this.instance.preventOutsideClick = true, this.toleranceReached = true, this.active = false, this.instance.preventOutsideClick = true, this.dragEnd(null), "right" == n2 && this.instance.prevSlide(), void ("left" == n2 && this.instance.nextSlide());
            }
            if (this.toleranceY > 0 && i2 > 0 && i2 >= t2 && (!this.lastDirection || "y" == this.lastDirection)) {
              this.xOffset = 0, this.lastDirection = "y", this.setTranslate(this.dragContainer, 0, this.currentY);
              var s2 = this.shouldClose();
              return !this.instance.settings.dragAutoSnap && s2 && (this.doSlideClose = true), void (this.instance.settings.dragAutoSnap && s2 && this.instance.close());
            }
          }
        }
      }, {
        key: "shouldChange",
        value: function() {
          var e2 = false;
          if (Math.abs(this.currentX) >= this.toleranceX) {
            var t2 = this.currentX > 0 ? "right" : "left";
            ("left" == t2 && this.slide !== this.slide.parentNode.lastChild || "right" == t2 && this.slide !== this.slide.parentNode.firstChild) && (e2 = t2);
          }
          return e2;
        }
      }, {
        key: "shouldClose",
        value: function() {
          var e2 = false;
          return Math.abs(this.currentY) >= this.toleranceY && (e2 = true), e2;
        }
      }, {
        key: "setTranslate",
        value: function(e2, t2, i2) {
          var n2 = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
          e2.style.transition = n2 ? "all .2s ease" : "", e2.style.transform = "translate3d(".concat(t2, "px, ").concat(i2, "px, 0)");
        }
      }]);
      function D(e2, t2, i2, n2) {
        var s2 = e2.querySelector(".gslide-media"), l2 = new Image(), o2 = "gSlideTitle_" + i2, r2 = "gSlideDesc_" + i2;
        l2.addEventListener("load", function() {
          C(n2) && n2();
        }, false), l2.src = t2.href, "" != t2.sizes && "" != t2.srcset && (l2.sizes = t2.sizes, l2.srcset = t2.srcset), l2.alt = "", O(t2.alt) || "" === t2.alt || (l2.alt = t2.alt), "" !== t2.title && l2.setAttribute("aria-labelledby", o2), "" !== t2.description && l2.setAttribute("aria-describedby", r2), t2.hasOwnProperty("_hasCustomWidth") && t2._hasCustomWidth && (l2.style.width = t2.width), t2.hasOwnProperty("_hasCustomHeight") && t2._hasCustomHeight && (l2.style.height = t2.height), s2.insertBefore(l2, s2.firstChild);
      }
      function _(e2, t2, i2, n2) {
        var s2 = this, l2 = e2.querySelector(".ginner-container"), o2 = "gvideo" + i2, r2 = e2.querySelector(".gslide-media"), a2 = this.getAllPlayers();
        d(l2, "gvideo-container"), r2.insertBefore(y('<div class="gvideo-wrapper"></div>'), r2.firstChild);
        var h2 = e2.querySelector(".gvideo-wrapper");
        w(this.settings.plyr.css, "Plyr");
        var c2 = t2.href, u2 = null == t2 ? void 0 : t2.videoProvider, g2 = false;
        r2.style.maxWidth = t2.width, w(this.settings.plyr.js, "Plyr", function() {
          if (!u2 && c2.match(/vimeo\.com\/([0-9]*)/) && (u2 = "vimeo"), !u2 && (c2.match(/(youtube\.com|youtube-nocookie\.com)\/watch\?v=([a-zA-Z0-9\-_]+)/) || c2.match(/youtu\.be\/([a-zA-Z0-9\-_]+)/) || c2.match(/(youtube\.com|youtube-nocookie\.com)\/embed\/([a-zA-Z0-9\-_]+)/) || c2.match(/(youtube\.com|youtube-nocookie\.com)\/shorts\/([a-zA-Z0-9\-_]+)/)) && (u2 = "youtube"), "local" === u2 || !u2) {
            u2 = "local";
            var l3 = '<video id="' + o2 + '" ';
            l3 += 'style="background:#000; max-width: '.concat(t2.width, ';" '), l3 += 'preload="metadata" ', l3 += 'x-webkit-airplay="allow" ', l3 += "playsinline ", l3 += "controls ", l3 += 'class="gvideo-local">', l3 += '<source src="'.concat(c2, '">'), g2 = y(l3 += "</video>");
          }
          var r3 = g2 || y('<div id="'.concat(o2, '" data-plyr-provider="').concat(u2, '" data-plyr-embed-id="').concat(c2, '"></div>'));
          d(h2, "".concat(u2, "-video gvideo")), h2.appendChild(r3), h2.setAttribute("data-id", o2), h2.setAttribute("data-index", i2);
          var v2 = P(s2.settings.plyr, "config") ? s2.settings.plyr.config : {}, f2 = new Plyr("#" + o2, v2);
          f2.on("ready", function(e3) {
            a2[o2] = e3.detail.plyr, C(n2) && n2();
          }), S(function() {
            return e2.querySelector("iframe") && "true" == e2.querySelector("iframe").dataset.ready;
          }, function() {
            s2.resize(e2);
          }), f2.on("enterfullscreen", W), f2.on("exitfullscreen", W);
        });
      }
      function W(e2) {
        var t2 = g(e2.target, ".gslide-media");
        "enterfullscreen" === e2.type && d(t2, "fullscreen"), "exitfullscreen" === e2.type && c(t2, "fullscreen");
      }
      function B(e2, t2, i2, n2) {
        var s2, l2 = this, o2 = e2.querySelector(".gslide-media"), r2 = !(!P(t2, "href") || !t2.href) && t2.href.split("#").pop().trim(), a2 = !(!P(t2, "content") || !t2.content) && t2.content;
        if (a2 && (k(a2) && (s2 = y('<div class="ginlined-content">'.concat(a2, "</div>"))), E(a2))) {
          "none" == a2.style.display && (a2.style.display = "block");
          var c2 = document.createElement("div");
          c2.className = "ginlined-content", c2.appendChild(a2), s2 = c2;
        }
        if (r2) {
          var u2 = document.getElementById(r2);
          if (!u2) return false;
          var g2 = u2.cloneNode(true);
          g2.style.height = t2.height, g2.style.maxWidth = t2.width, d(g2, "ginlined-content"), s2 = g2;
        }
        if (!s2) return console.error("Unable to append inline slide content", t2), false;
        o2.style.height = t2.height, o2.style.width = t2.width, o2.appendChild(s2), this.events["inlineclose" + r2] = h("click", {
          onElement: o2.querySelectorAll(".gtrigger-close"),
          withCallback: function(e3) {
            e3.preventDefault(), l2.close();
          }
        }), C(n2) && n2();
      }
      function H(e2, t2, i2, n2) {
        var s2 = e2.querySelector(".gslide-media"), l2 = function(e3) {
          var t3 = e3.url, i3 = e3.allow, n3 = e3.callback, s3 = e3.appendTo, l3 = document.createElement("iframe");
          return l3.className = "vimeo-video gvideo", l3.src = t3, l3.style.width = "100%", l3.style.height = "100%", i3 && l3.setAttribute("allow", i3), l3.onload = function() {
            l3.onload = null, d(l3, "node-ready"), C(n3) && n3();
          }, s3 && s3.appendChild(l3), l3;
        }({
          url: t2.href,
          callback: n2
        });
        s2.parentNode.style.maxWidth = t2.width, s2.parentNode.style.height = t2.height, s2.appendChild(l2);
      }
      var j = i(function t2() {
        var i2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        e(this, t2), this.defaults = {
          href: "",
          sizes: "",
          srcset: "",
          title: "",
          type: "",
          videoProvider: "",
          description: "",
          alt: "",
          descPosition: "bottom",
          effect: "",
          width: "",
          height: "",
          content: false,
          zoomable: true,
          draggable: true
        }, I(i2) && (this.defaults = o(this.defaults, i2));
      }, [{
        key: "sourceType",
        value: function(e2) {
          var t2 = e2;
          return null !== (e2 = e2.toLowerCase()).match(/\.(jpeg|jpg|jpe|gif|png|apn|webp|avif|svg)/) ? "image" : e2.match(/(youtube\.com|youtube-nocookie\.com)\/watch\?v=([a-zA-Z0-9\-_]+)/) || e2.match(/youtu\.be\/([a-zA-Z0-9\-_]+)/) || e2.match(/(youtube\.com|youtube-nocookie\.com)\/embed\/([a-zA-Z0-9\-_]+)/) || e2.match(/(youtube\.com|youtube-nocookie\.com)\/shorts\/([a-zA-Z0-9\-_]+)/) || e2.match(/vimeo\.com\/([0-9]*)/) || null !== e2.match(/\.(mp4|ogg|webm|mov)/) ? "video" : null !== e2.match(/\.(mp3|wav|wma|aac|ogg)/) ? "audio" : e2.indexOf("#") > -1 && "" !== t2.split("#").pop().trim() ? "inline" : e2.indexOf("goajax=true") > -1 ? "ajax" : "external";
        }
      }, {
        key: "parseConfig",
        value: function(e2, t2) {
          var i2 = this, n2 = o({
            descPosition: t2.descPosition
          }, this.defaults);
          if (I(e2) && !E(e2)) {
            P(e2, "type") || (P(e2, "content") && e2.content ? e2.type = "inline" : P(e2, "href") && (e2.type = this.sourceType(e2.href)));
            var s2 = o(n2, e2);
            return this.setSize(s2, t2), s2;
          }
          var l2 = "", a2 = e2.getAttribute("data-glightbox"), h2 = e2.nodeName.toLowerCase();
          if ("a" === h2 && (l2 = e2.href), "img" === h2 && (l2 = e2.src, n2.alt = e2.alt), n2.href = l2, r(n2, function(s3, l3) {
            P(t2, l3) && "width" !== l3 && (n2[l3] = t2[l3]);
            var o2 = e2.dataset[l3];
            O(o2) || (n2[l3] = i2.sanitizeValue(o2));
          }), n2.content && (n2.type = "inline"), !n2.type && l2 && (n2.type = this.sourceType(l2)), O(a2)) {
            if (!n2.title && "a" == h2) {
              var d2 = e2.title;
              O(d2) || "" === d2 || (n2.title = d2);
            }
            if (!n2.title && "img" == h2) {
              var c2 = e2.alt;
              O(c2) || "" === c2 || (n2.title = c2);
            }
          } else {
            var u2 = [];
            r(n2, function(e3, t3) {
              u2.push(";\\s?" + t3);
            }), u2 = u2.join("\\s?:|"), "" !== a2.trim() && r(n2, function(e3, t3) {
              var s3 = a2, l3 = new RegExp("s?" + t3 + "s?:s?(.*?)(" + u2 + "s?:|$)"), o2 = s3.match(l3);
              if (o2 && o2.length && o2[1]) {
                var r2 = o2[1].trim().replace(/;\s*$/, "");
                n2[t3] = i2.sanitizeValue(r2);
              }
            });
          }
          if (n2.description && "." === n2.description.substring(0, 1)) {
            var g2;
            try {
              g2 = document.querySelector(n2.description).innerHTML;
            } catch (e3) {
              if (!(e3 instanceof DOMException)) throw e3;
            }
            g2 && (n2.description = g2);
          }
          if (!n2.description) {
            var v2 = e2.querySelector(".glightbox-desc");
            v2 && (n2.description = v2.innerHTML);
          }
          return this.setSize(n2, t2, e2), this.slideConfig = n2, n2;
        }
      }, {
        key: "setSize",
        value: function(e2, t2) {
          var i2 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, n2 = "video" == e2.type ? this.checkSize(t2.videosWidth) : this.checkSize(t2.width), s2 = this.checkSize(t2.height);
          return e2.width = P(e2, "width") && "" !== e2.width ? this.checkSize(e2.width) : n2, e2.height = P(e2, "height") && "" !== e2.height ? this.checkSize(e2.height) : s2, i2 && "image" == e2.type && (e2._hasCustomWidth = !!i2.dataset.width, e2._hasCustomHeight = !!i2.dataset.height), e2;
        }
      }, {
        key: "checkSize",
        value: function(e2) {
          return z(e2) ? "".concat(e2, "px") : e2;
        }
      }, {
        key: "sanitizeValue",
        value: function(e2) {
          return "true" !== e2 && "false" !== e2 ? e2 : "true" === e2;
        }
      }]), V = i(function t2(i2, n2, s2) {
        e(this, t2), this.element = i2, this.instance = n2, this.index = s2;
      }, [{
        key: "setContent",
        value: function() {
          var e2 = this, t2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, i2 = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          if (u(t2, "loaded")) return false;
          var n2 = this.instance.settings, s2 = this.slideConfig, l2 = T();
          C(n2.beforeSlideLoad) && n2.beforeSlideLoad({
            index: this.index,
            slide: t2,
            player: false
          });
          var o2 = s2.type, r2 = s2.descPosition, a2 = t2.querySelector(".gslide-media"), h2 = t2.querySelector(".gslide-title"), c2 = t2.querySelector(".gslide-desc"), g2 = t2.querySelector(".gdesc-inner"), v2 = i2, f2 = "gSlideTitle_" + this.index, p2 = "gSlideDesc_" + this.index;
          if (C(n2.afterSlideLoad) && (v2 = function() {
            C(i2) && i2(), n2.afterSlideLoad({
              index: e2.index,
              slide: t2,
              player: e2.instance.getSlidePlayerInstance(e2.index)
            });
          }), "" == s2.title && "" == s2.description ? g2 && g2.parentNode.parentNode.removeChild(g2.parentNode) : (h2 && "" !== s2.title ? (h2.id = f2, h2.innerHTML = s2.title) : h2.parentNode.removeChild(h2), c2 && "" !== s2.description ? (c2.id = p2, l2 && n2.moreLength > 0 ? (s2.smallDescription = this.slideShortDesc(s2.description, n2.moreLength, n2.moreText), c2.innerHTML = s2.smallDescription, this.descriptionEvents(c2, s2)) : c2.innerHTML = s2.description) : c2.parentNode.removeChild(c2), d(a2.parentNode, "desc-".concat(r2)), d(g2.parentNode, "description-".concat(r2))), d(a2, "gslide-".concat(o2)), d(t2, "loaded"), "video" !== o2) {
            if ("external" !== o2) return "inline" === o2 ? (B.apply(this.instance, [t2, s2, this.index, v2]), void (s2.draggable && new N({
              dragEl: t2.querySelector(".gslide-inline"),
              toleranceX: n2.dragToleranceX,
              toleranceY: n2.dragToleranceY,
              slide: t2,
              instance: this.instance
            }))) : void ("image" !== o2 ? C(v2) && v2() : D(t2, s2, this.index, function() {
              var i3 = t2.querySelector("img");
              s2.draggable && new N({
                dragEl: i3,
                toleranceX: n2.dragToleranceX,
                toleranceY: n2.dragToleranceY,
                slide: t2,
                instance: e2.instance
              }), s2.zoomable && i3.naturalWidth > i3.offsetWidth && (d(i3, "zoomable"), new q(i3, t2, function() {
                e2.instance.resize();
              })), C(v2) && v2();
            }));
            H.apply(this, [t2, s2, this.index, v2]);
          } else _.apply(this.instance, [t2, s2, this.index, v2]);
        }
      }, {
        key: "slideShortDesc",
        value: function(e2) {
          var t2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 50, i2 = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], n2 = document.createElement("div");
          n2.innerHTML = e2;
          var s2 = n2.innerText, l2 = i2;
          if ((e2 = s2.trim()).length <= t2) return e2;
          var o2 = e2.substr(0, t2 - 1);
          return l2 ? (n2 = null, o2 + '... <a href="#" class="desc-more">' + i2 + "</a>") : o2;
        }
      }, {
        key: "descriptionEvents",
        value: function(e2, t2) {
          var i2 = this, n2 = e2.querySelector(".desc-more");
          if (!n2) return false;
          h("click", {
            onElement: n2,
            withCallback: function(e3, n3) {
              e3.preventDefault();
              var s2 = document.body, l2 = g(n3, ".gslide-desc");
              if (!l2) return false;
              l2.innerHTML = t2.description, d(s2, "gdesc-open");
              var o2 = h("click", {
                onElement: [s2, g(l2, ".gslide-description")],
                withCallback: function(e4, n4) {
                  "a" !== e4.target.nodeName.toLowerCase() && (c(s2, "gdesc-open"), d(s2, "gdesc-closed"), l2.innerHTML = t2.smallDescription, i2.descriptionEvents(l2, t2), setTimeout(function() {
                    c(s2, "gdesc-closed");
                  }, 400), o2.destroy());
                }
              });
            }
          });
        }
      }, {
        key: "create",
        value: function() {
          return y(this.instance.settings.slideHTML);
        }
      }, {
        key: "getConfig",
        value: function() {
          E(this.element) || this.element.hasOwnProperty("draggable") || (this.element.draggable = this.instance.settings.draggable);
          var e2 = new j(this.instance.settings.slideExtraAttributes);
          return this.slideConfig = e2.parseConfig(this.element, this.instance.settings), this.slideConfig;
        }
      }]);
      function F(e2) {
        return Math.sqrt(e2.x * e2.x + e2.y * e2.y);
      }
      function R(e2, t2) {
        var i2 = function(e3, t3) {
          var i3 = F(e3) * F(t3);
          if (0 === i3) return 0;
          var n2 = function(e4, t4) {
            return e4.x * t4.x + e4.y * t4.y;
          }(e3, t3) / i3;
          return n2 > 1 && (n2 = 1), Math.acos(n2);
        }(e2, t2);
        return function(e3, t3) {
          return e3.x * t3.y - t3.x * e3.y;
        }(e2, t2) > 0 && (i2 *= -1), 180 * i2 / Math.PI;
      }
      var G = i(function t2(i2) {
        e(this, t2), this.handlers = [], this.el = i2;
      }, [{
        key: "add",
        value: function(e2) {
          this.handlers.push(e2);
        }
      }, {
        key: "del",
        value: function(e2) {
          e2 || (this.handlers = []);
          for (var t2 = this.handlers.length; t2 >= 0; t2--) this.handlers[t2] === e2 && this.handlers.splice(t2, 1);
        }
      }, {
        key: "dispatch",
        value: function() {
          for (var e2 = 0, t2 = this.handlers.length; e2 < t2; e2++) {
            var i2 = this.handlers[e2];
            "function" == typeof i2 && i2.apply(this.el, arguments);
          }
        }
      }]);
      function Z(e2, t2) {
        var i2 = new G(e2);
        return i2.add(t2), i2;
      }
      var U = i(function t2(i2, n2) {
        e(this, t2), this.element = "string" == typeof i2 ? document.querySelector(i2) : i2, this.start = this.start.bind(this), this.move = this.move.bind(this), this.end = this.end.bind(this), this.cancel = this.cancel.bind(this), this.element.addEventListener("touchstart", this.start, false), this.element.addEventListener("touchmove", this.move, false), this.element.addEventListener("touchend", this.end, false), this.element.addEventListener("touchcancel", this.cancel, false), this.preV = {
          x: null,
          y: null
        }, this.pinchStartLen = null, this.zoom = 1, this.isDoubleTap = false;
        var s2 = function() {
        };
        this.rotate = Z(this.element, n2.rotate || s2), this.touchStart = Z(this.element, n2.touchStart || s2), this.multipointStart = Z(this.element, n2.multipointStart || s2), this.multipointEnd = Z(this.element, n2.multipointEnd || s2), this.pinch = Z(this.element, n2.pinch || s2), this.swipe = Z(this.element, n2.swipe || s2), this.tap = Z(this.element, n2.tap || s2), this.doubleTap = Z(this.element, n2.doubleTap || s2), this.longTap = Z(this.element, n2.longTap || s2), this.singleTap = Z(this.element, n2.singleTap || s2), this.pressMove = Z(this.element, n2.pressMove || s2), this.twoFingerPressMove = Z(this.element, n2.twoFingerPressMove || s2), this.touchMove = Z(this.element, n2.touchMove || s2), this.touchEnd = Z(this.element, n2.touchEnd || s2), this.touchCancel = Z(this.element, n2.touchCancel || s2), this.translateContainer = this.element, this._cancelAllHandler = this.cancelAll.bind(this), window.addEventListener("scroll", this._cancelAllHandler), this.delta = null, this.last = null, this.now = null, this.tapTimeout = null, this.singleTapTimeout = null, this.longTapTimeout = null, this.swipeTimeout = null, this.x1 = this.x2 = this.y1 = this.y2 = null, this.preTapPosition = {
          x: null,
          y: null
        };
      }, [{
        key: "start",
        value: function(e2) {
          if (e2.touches) if (e2.target && e2.target.nodeName && ["a", "button", "input"].indexOf(e2.target.nodeName.toLowerCase()) >= 0) console.log("ignore drag for this touched element", e2.target.nodeName.toLowerCase());
          else {
            this.now = Date.now(), this.x1 = e2.touches[0].pageX, this.y1 = e2.touches[0].pageY, this.delta = this.now - (this.last || this.now), this.touchStart.dispatch(e2, this.element), null !== this.preTapPosition.x && (this.isDoubleTap = this.delta > 0 && this.delta <= 250 && Math.abs(this.preTapPosition.x - this.x1) < 30 && Math.abs(this.preTapPosition.y - this.y1) < 30, this.isDoubleTap && clearTimeout(this.singleTapTimeout)), this.preTapPosition.x = this.x1, this.preTapPosition.y = this.y1, this.last = this.now;
            var t2 = this.preV;
            if (e2.touches.length > 1) {
              this._cancelLongTap(), this._cancelSingleTap();
              var i2 = {
                x: e2.touches[1].pageX - this.x1,
                y: e2.touches[1].pageY - this.y1
              };
              t2.x = i2.x, t2.y = i2.y, this.pinchStartLen = F(t2), this.multipointStart.dispatch(e2, this.element);
            }
            this._preventTap = false, this.longTapTimeout = setTimeout(function() {
              this.longTap.dispatch(e2, this.element), this._preventTap = true;
            }.bind(this), 750);
          }
        }
      }, {
        key: "move",
        value: function(e2) {
          if (e2.touches) {
            var t2 = this.preV, i2 = e2.touches.length, n2 = e2.touches[0].pageX, s2 = e2.touches[0].pageY;
            if (this.isDoubleTap = false, i2 > 1) {
              var l2 = e2.touches[1].pageX, o2 = e2.touches[1].pageY, r2 = {
                x: e2.touches[1].pageX - n2,
                y: e2.touches[1].pageY - s2
              };
              null !== t2.x && (this.pinchStartLen > 0 && (e2.zoom = F(r2) / this.pinchStartLen, this.pinch.dispatch(e2, this.element)), e2.angle = R(r2, t2), this.rotate.dispatch(e2, this.element)), t2.x = r2.x, t2.y = r2.y, null !== this.x2 && null !== this.sx2 ? (e2.deltaX = (n2 - this.x2 + l2 - this.sx2) / 2, e2.deltaY = (s2 - this.y2 + o2 - this.sy2) / 2) : (e2.deltaX = 0, e2.deltaY = 0), this.twoFingerPressMove.dispatch(e2, this.element), this.sx2 = l2, this.sy2 = o2;
            } else {
              if (null !== this.x2) {
                e2.deltaX = n2 - this.x2, e2.deltaY = s2 - this.y2;
                var a2 = Math.abs(this.x1 - this.x2), h2 = Math.abs(this.y1 - this.y2);
                (a2 > 10 || h2 > 10) && (this._preventTap = true);
              } else e2.deltaX = 0, e2.deltaY = 0;
              this.pressMove.dispatch(e2, this.element);
            }
            this.touchMove.dispatch(e2, this.element), this._cancelLongTap(), this.x2 = n2, this.y2 = s2, i2 > 1 && e2.preventDefault();
          }
        }
      }, {
        key: "end",
        value: function(e2) {
          if (e2.changedTouches) {
            this._cancelLongTap();
            var t2 = this;
            e2.touches.length < 2 && (this.multipointEnd.dispatch(e2, this.element), this.sx2 = this.sy2 = null), this.x2 && Math.abs(this.x1 - this.x2) > 30 || this.y2 && Math.abs(this.y1 - this.y2) > 30 ? (e2.direction = this._swipeDirection(this.x1, this.x2, this.y1, this.y2), this.swipeTimeout = setTimeout(function() {
              t2.swipe.dispatch(e2, t2.element);
            }, 0)) : (this.tapTimeout = setTimeout(function() {
              t2._preventTap || t2.tap.dispatch(e2, t2.element), t2.isDoubleTap && (t2.doubleTap.dispatch(e2, t2.element), t2.isDoubleTap = false);
            }, 0), t2.isDoubleTap || (t2.singleTapTimeout = setTimeout(function() {
              t2.singleTap.dispatch(e2, t2.element);
            }, 250))), this.touchEnd.dispatch(e2, this.element), this.preV.x = 0, this.preV.y = 0, this.zoom = 1, this.pinchStartLen = null, this.x1 = this.x2 = this.y1 = this.y2 = null;
          }
        }
      }, {
        key: "cancelAll",
        value: function() {
          this._preventTap = true, clearTimeout(this.singleTapTimeout), clearTimeout(this.tapTimeout), clearTimeout(this.longTapTimeout), clearTimeout(this.swipeTimeout);
        }
      }, {
        key: "cancel",
        value: function(e2) {
          this.cancelAll(), this.touchCancel.dispatch(e2, this.element);
        }
      }, {
        key: "_cancelLongTap",
        value: function() {
          clearTimeout(this.longTapTimeout);
        }
      }, {
        key: "_cancelSingleTap",
        value: function() {
          clearTimeout(this.singleTapTimeout);
        }
      }, {
        key: "_swipeDirection",
        value: function(e2, t2, i2, n2) {
          return Math.abs(e2 - t2) >= Math.abs(i2 - n2) ? e2 - t2 > 0 ? "Left" : "Right" : i2 - n2 > 0 ? "Up" : "Down";
        }
      }, {
        key: "on",
        value: function(e2, t2) {
          this[e2] && this[e2].add(t2);
        }
      }, {
        key: "off",
        value: function(e2, t2) {
          this[e2] && this[e2].del(t2);
        }
      }, {
        key: "destroy",
        value: function() {
          return this.singleTapTimeout && clearTimeout(this.singleTapTimeout), this.tapTimeout && clearTimeout(this.tapTimeout), this.longTapTimeout && clearTimeout(this.longTapTimeout), this.swipeTimeout && clearTimeout(this.swipeTimeout), this.element.removeEventListener("touchstart", this.start), this.element.removeEventListener("touchmove", this.move), this.element.removeEventListener("touchend", this.end), this.element.removeEventListener("touchcancel", this.cancel), this.rotate.del(), this.touchStart.del(), this.multipointStart.del(), this.multipointEnd.del(), this.pinch.del(), this.swipe.del(), this.tap.del(), this.doubleTap.del(), this.longTap.del(), this.singleTap.del(), this.pressMove.del(), this.twoFingerPressMove.del(), this.touchMove.del(), this.touchEnd.del(), this.touchCancel.del(), this.preV = this.pinchStartLen = this.zoom = this.isDoubleTap = this.delta = this.last = this.now = this.tapTimeout = this.singleTapTimeout = this.longTapTimeout = this.swipeTimeout = this.x1 = this.x2 = this.y1 = this.y2 = this.preTapPosition = this.rotate = this.touchStart = this.multipointStart = this.multipointEnd = this.pinch = this.swipe = this.tap = this.doubleTap = this.longTap = this.singleTap = this.pressMove = this.touchMove = this.touchEnd = this.touchCancel = this.twoFingerPressMove = null, window.removeEventListener("scroll", this._cancelAllHandler), null;
        }
      }]);
      function $(e2) {
        var t2 = function() {
          var e3, t3 = document.createElement("fakeelement"), i3 = {
            transition: "transitionend",
            OTransition: "oTransitionEnd",
            MozTransition: "transitionend",
            WebkitTransition: "webkitTransitionEnd"
          };
          for (e3 in i3) if (void 0 !== t3.style[e3]) return i3[e3];
        }(), i2 = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth, n2 = u(e2, "gslide-media") ? e2 : e2.querySelector(".gslide-media"), s2 = g(n2, ".ginner-container"), l2 = e2.querySelector(".gslide-description");
        i2 > 769 && (n2 = s2), d(n2, "greset"), f(n2, "translate3d(0, 0, 0)"), h(t2, {
          onElement: n2,
          once: true,
          withCallback: function(e3, t3) {
            c(n2, "greset");
          }
        }), n2.style.opacity = "", l2 && (l2.style.opacity = "");
      }
      function J(e2) {
        if (e2.events.hasOwnProperty("touch")) return false;
        var t2, i2, n2, s2 = x(), l2 = s2.width, o2 = s2.height, r2 = false, a2 = null, h2 = null, v2 = null, p2 = false, m2 = 1, y2 = 1, b2 = false, S2 = false, w2 = null, T2 = null, C2 = null, k2 = null, E2 = 0, A2 = 0, L2 = false, I2 = false, O2 = {}, P2 = {}, M2 = 0, z2 = 0, X2 = document.getElementById("glightbox-slider"), Y2 = document.querySelector(".goverlay"), q2 = new U(X2, {
          touchStart: function(t3) {
            if (r2 = true, (u(t3.targetTouches[0].target, "ginner-container") || g(t3.targetTouches[0].target, ".gslide-desc") || "a" == t3.targetTouches[0].target.nodeName.toLowerCase()) && (r2 = false), g(t3.targetTouches[0].target, ".gslide-inline") && !u(t3.targetTouches[0].target.parentNode, "gslide-inline") && (r2 = false), r2) {
              if (P2 = t3.targetTouches[0], O2.pageX = t3.targetTouches[0].pageX, O2.pageY = t3.targetTouches[0].pageY, M2 = t3.targetTouches[0].clientX, z2 = t3.targetTouches[0].clientY, a2 = e2.activeSlide, h2 = a2.querySelector(".gslide-media"), n2 = a2.querySelector(".gslide-inline"), v2 = null, u(h2, "gslide-image") && (v2 = h2.querySelector("img")), (window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth) > 769 && (h2 = a2.querySelector(".ginner-container")), c(Y2, "greset"), t3.pageX > 20 && t3.pageX < window.innerWidth - 20) return;
              t3.preventDefault();
            }
          },
          touchMove: function(s3) {
            if (r2 && (P2 = s3.targetTouches[0], !b2 && !S2)) {
              if (n2 && n2.offsetHeight > o2) {
                var a3 = O2.pageX - P2.pageX;
                if (Math.abs(a3) <= 13) return false;
              }
              p2 = true;
              var d2, c2 = s3.targetTouches[0].clientX, u2 = s3.targetTouches[0].clientY, g2 = M2 - c2, m3 = z2 - u2;
              if (Math.abs(g2) > Math.abs(m3) ? (L2 = false, I2 = true) : (I2 = false, L2 = true), t2 = P2.pageX - O2.pageX, E2 = 100 * t2 / l2, i2 = P2.pageY - O2.pageY, A2 = 100 * i2 / o2, L2 && v2 && (d2 = 1 - Math.abs(i2) / o2, Y2.style.opacity = d2, e2.settings.touchFollowAxis && (E2 = 0)), I2 && (d2 = 1 - Math.abs(t2) / l2, h2.style.opacity = d2, e2.settings.touchFollowAxis && (A2 = 0)), !v2) return f(h2, "translate3d(".concat(E2, "%, 0, 0)"));
              f(h2, "translate3d(".concat(E2, "%, ").concat(A2, "%, 0)"));
            }
          },
          touchEnd: function() {
            if (r2) {
              if (p2 = false, S2 || b2) return C2 = w2, void (k2 = T2);
              var t3 = Math.abs(parseInt(A2)), i3 = Math.abs(parseInt(E2));
              if (!(t3 > 29 && v2)) return t3 < 29 && i3 < 25 ? (d(Y2, "greset"), Y2.style.opacity = 1, $(h2)) : void 0;
              e2.close();
            }
          },
          multipointEnd: function() {
            setTimeout(function() {
              b2 = false;
            }, 50);
          },
          multipointStart: function() {
            b2 = true, m2 = y2 || 1;
          },
          pinch: function(e3) {
            if (!v2 || p2) return false;
            b2 = true, v2.scaleX = v2.scaleY = m2 * e3.zoom;
            var t3 = m2 * e3.zoom;
            if (S2 = true, t3 <= 1) return S2 = false, t3 = 1, k2 = null, C2 = null, w2 = null, T2 = null, void v2.setAttribute("style", "");
            t3 > 4.5 && (t3 = 4.5), v2.style.transform = "scale3d(".concat(t3, ", ").concat(t3, ", 1)"), y2 = t3;
          },
          pressMove: function(e3) {
            if (S2 && !b2) {
              var t3 = P2.pageX - O2.pageX, i3 = P2.pageY - O2.pageY;
              C2 && (t3 += C2), k2 && (i3 += k2), w2 = t3, T2 = i3;
              var n3 = "translate3d(".concat(t3, "px, ").concat(i3, "px, 0)");
              y2 && (n3 += " scale3d(".concat(y2, ", ").concat(y2, ", 1)")), f(v2, n3);
            }
          },
          swipe: function(t3) {
            if (!S2) if (b2) b2 = false;
            else {
              if ("Left" == t3.direction) {
                if (e2.index == e2.elements.length - 1) return $(h2);
                e2.nextSlide();
              }
              if ("Right" == t3.direction) {
                if (0 == e2.index) return $(h2);
                e2.prevSlide();
              }
            }
          }
        });
        e2.events.touch = q2;
      }
      var K = T(), Q = null !== T() || void 0 !== document.createTouch || "ontouchstart" in window || "onmsgesturechange" in window || navigator.msMaxTouchPoints, ee = document.getElementsByTagName("html")[0], te = {
        selector: ".glightbox",
        elements: null,
        skin: "clean",
        theme: "clean",
        closeButton: true,
        startAt: null,
        autoplayVideos: true,
        autofocusVideos: true,
        descPosition: "bottom",
        width: "900px",
        height: "506px",
        videosWidth: "960px",
        beforeSlideChange: null,
        afterSlideChange: null,
        beforeSlideLoad: null,
        afterSlideLoad: null,
        slideInserted: null,
        slideRemoved: null,
        slideExtraAttributes: null,
        onOpen: null,
        onClose: null,
        loop: false,
        zoomable: true,
        draggable: true,
        dragAutoSnap: false,
        dragToleranceX: 40,
        dragToleranceY: 65,
        preload: true,
        oneSlidePerOpen: false,
        touchNavigation: true,
        touchFollowAxis: true,
        keyboardNavigation: true,
        closeOnOutsideClick: true,
        plugins: false,
        plyr: {
          css: "https://cdn.plyr.io/3.6.12/plyr.css",
          js: "https://cdn.plyr.io/3.6.12/plyr.js",
          config: {
            ratio: "16:9",
            fullscreen: {
              enabled: true,
              iosNative: true
            },
            youtube: {
              noCookie: true,
              rel: 0,
              showinfo: 0,
              iv_load_policy: 3
            },
            vimeo: {
              byline: false,
              portrait: false,
              title: false,
              transparent: false
            }
          }
        },
        openEffect: "zoom",
        closeEffect: "zoom",
        slideEffect: "slide",
        moreText: "See more",
        moreLength: 60,
        cssEfects: {
          fade: {
            in: "fadeIn",
            out: "fadeOut"
          },
          zoom: {
            in: "zoomIn",
            out: "zoomOut"
          },
          slide: {
            in: "slideInRight",
            out: "slideOutLeft"
          },
          slideBack: {
            in: "slideInLeft",
            out: "slideOutRight"
          },
          none: {
            in: "none",
            out: "none"
          }
        },
        svg: {
          close: '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" xml:space="preserve"><g><g><path d="M505.943,6.058c-8.077-8.077-21.172-8.077-29.249,0L6.058,476.693c-8.077,8.077-8.077,21.172,0,29.249C10.096,509.982,15.39,512,20.683,512c5.293,0,10.586-2.019,14.625-6.059L505.943,35.306C514.019,27.23,514.019,14.135,505.943,6.058z"/></g></g><g><g><path d="M505.942,476.694L35.306,6.059c-8.076-8.077-21.172-8.077-29.248,0c-8.077,8.076-8.077,21.171,0,29.248l470.636,470.636c4.038,4.039,9.332,6.058,14.625,6.058c5.293,0,10.587-2.019,14.624-6.057C514.018,497.866,514.018,484.771,505.942,476.694z"/></g></g></svg>',
          next: '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 477.175 477.175" xml:space="preserve"> <g><path d="M360.731,229.075l-225.1-225.1c-5.3-5.3-13.8-5.3-19.1,0s-5.3,13.8,0,19.1l215.5,215.5l-215.5,215.5c-5.3,5.3-5.3,13.8,0,19.1c2.6,2.6,6.1,4,9.5,4c3.4,0,6.9-1.3,9.5-4l225.1-225.1C365.931,242.875,365.931,234.275,360.731,229.075z"/></g></svg>',
          prev: '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 477.175 477.175" xml:space="preserve"><g><path d="M145.188,238.575l215.5-215.5c5.3-5.3,5.3-13.8,0-19.1s-13.8-5.3-19.1,0l-225.1,225.1c-5.3,5.3-5.3,13.8,0,19.1l225.1,225c2.6,2.6,6.1,4,9.5,4s6.9-1.3,9.5-4c5.3-5.3,5.3-13.8,0-19.1L145.188,238.575z"/></g></svg>'
        },
        slideHTML: '<div class="gslide">\n    <div class="gslide-inner-content">\n        <div class="ginner-container">\n            <div class="gslide-media">\n            </div>\n            <div class="gslide-description">\n                <div class="gdesc-inner">\n                    <h4 class="gslide-title"></h4>\n                    <div class="gslide-desc"></div>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>',
        lightboxHTML: '<div id="glightbox-body" class="glightbox-container" tabindex="-1" role="dialog" aria-hidden="false">\n    <div class="gloader visible"></div>\n    <div class="goverlay"></div>\n    <div class="gcontainer">\n    <div id="glightbox-slider" class="gslider"></div>\n    <button class="gclose gbtn" aria-label="Close" data-taborder="3">{closeSVG}</button>\n    <button class="gprev gbtn" aria-label="Previous" data-taborder="2">{prevSVG}</button>\n    <button class="gnext gbtn" aria-label="Next" data-taborder="1">{nextSVG}</button>\n</div>\n</div>'
      }, ie = i(function t2() {
        var i2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        e(this, t2), this.customOptions = i2, this.settings = o(te, i2), this.effectsClasses = this.getAnimationClasses(), this.videoPlayers = {}, this.apiEvents = [], this.fullElementsList = false;
      }, [{
        key: "init",
        value: function() {
          var e2 = this, t2 = this.getSelector();
          t2 && (this.baseEvents = h("click", {
            onElement: t2,
            withCallback: function(t3, i2) {
              t3.preventDefault(), e2.open(i2);
            }
          })), this.elements = this.getElements();
        }
      }, {
        key: "open",
        value: function() {
          var e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          if (0 === this.elements.length) return false;
          this.activeSlide = null, this.prevActiveSlideIndex = null, this.prevActiveSlide = null;
          var i2 = z(t2) ? t2 : this.settings.startAt;
          if (E(e2)) {
            var n2 = e2.getAttribute("data-gallery");
            n2 && (this.fullElementsList = this.elements, this.elements = this.getGalleryElements(this.elements, n2)), O(i2) && (i2 = this.getElementIndex(e2)) < 0 && (i2 = 0);
          }
          z(i2) || (i2 = 0), this.build(), v(this.overlay, "none" === this.settings.openEffect ? "none" : this.settings.cssEfects.fade.in);
          var s2 = document.body, l2 = window.innerWidth - document.documentElement.clientWidth;
          if (l2 > 0) {
            var o2 = document.createElement("style");
            o2.type = "text/css", o2.className = "gcss-styles", o2.innerText = ".gscrollbar-fixer {margin-right: ".concat(l2, "px}"), document.head.appendChild(o2), d(s2, "gscrollbar-fixer");
          }
          d(s2, "glightbox-open"), d(ee, "glightbox-open"), K && (d(document.body, "glightbox-mobile"), this.settings.slideEffect = "slide"), this.showSlide(i2, true), 1 === this.elements.length ? (d(this.prevButton, "glightbox-button-hidden"), d(this.nextButton, "glightbox-button-hidden")) : (c(this.prevButton, "glightbox-button-hidden"), c(this.nextButton, "glightbox-button-hidden")), this.lightboxOpen = true, this.trigger("open"), C(this.settings.onOpen) && this.settings.onOpen(), Q && this.settings.touchNavigation && J(this), this.settings.keyboardNavigation && Y(this);
        }
      }, {
        key: "openAt",
        value: function() {
          var e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
          this.open(null, e2);
        }
      }, {
        key: "showSlide",
        value: function() {
          var e2 = this, t2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, i2 = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          p(this.loader), this.index = parseInt(t2);
          var n2 = this.slidesContainer.querySelector(".current");
          n2 && c(n2, "current"), this.slideAnimateOut();
          var s2 = this.slidesContainer.querySelectorAll(".gslide")[t2];
          if (u(s2, "loaded")) this.slideAnimateIn(s2, i2), m(this.loader);
          else {
            p(this.loader);
            var l2 = this.elements[t2], o2 = {
              index: this.index,
              slide: s2,
              slideNode: s2,
              slideConfig: l2.slideConfig,
              slideIndex: this.index,
              trigger: l2.node,
              player: null
            };
            this.trigger("slide_before_load", o2), l2.instance.setContent(s2, function() {
              m(e2.loader), e2.resize(), e2.slideAnimateIn(s2, i2), e2.trigger("slide_after_load", o2);
            });
          }
          this.slideDescription = s2.querySelector(".gslide-description"), this.slideDescriptionContained = this.slideDescription && u(this.slideDescription.parentNode, "gslide-media"), this.settings.preload && (this.preloadSlide(t2 + 1), this.preloadSlide(t2 - 1)), this.updateNavigationClasses(), this.activeSlide = s2;
        }
      }, {
        key: "preloadSlide",
        value: function(e2) {
          var t2 = this;
          if (e2 < 0 || e2 > this.elements.length - 1) return false;
          if (O(this.elements[e2])) return false;
          var i2 = this.slidesContainer.querySelectorAll(".gslide")[e2];
          if (u(i2, "loaded")) return false;
          var n2 = this.elements[e2], s2 = n2.type, l2 = {
            index: e2,
            slide: i2,
            slideNode: i2,
            slideConfig: n2.slideConfig,
            slideIndex: e2,
            trigger: n2.node,
            player: null
          };
          this.trigger("slide_before_load", l2), "video" === s2 || "external" === s2 ? setTimeout(function() {
            n2.instance.setContent(i2, function() {
              t2.trigger("slide_after_load", l2);
            });
          }, 200) : n2.instance.setContent(i2, function() {
            t2.trigger("slide_after_load", l2);
          });
        }
      }, {
        key: "prevSlide",
        value: function() {
          this.goToSlide(this.index - 1);
        }
      }, {
        key: "nextSlide",
        value: function() {
          this.goToSlide(this.index + 1);
        }
      }, {
        key: "goToSlide",
        value: function() {
          var e2 = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          if (this.prevActiveSlide = this.activeSlide, this.prevActiveSlideIndex = this.index, !this.loop() && (e2 < 0 || e2 > this.elements.length - 1)) return false;
          e2 < 0 ? e2 = this.elements.length - 1 : e2 >= this.elements.length && (e2 = 0), this.showSlide(e2);
        }
      }, {
        key: "insertSlide",
        value: function() {
          var e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
          t2 < 0 && (t2 = this.elements.length);
          var i2 = new V(e2, this, t2), n2 = i2.getConfig(), s2 = o({}, n2), l2 = i2.create(), r2 = this.elements.length - 1;
          s2.index = t2, s2.node = false, s2.instance = i2, s2.slideConfig = n2, this.elements.splice(t2, 0, s2);
          var a2 = null, h2 = null;
          if (this.slidesContainer) {
            if (t2 > r2) this.slidesContainer.appendChild(l2);
            else {
              var d2 = this.slidesContainer.querySelectorAll(".gslide")[t2];
              this.slidesContainer.insertBefore(l2, d2);
            }
            (this.settings.preload && 0 == this.index && 0 == t2 || this.index - 1 == t2 || this.index + 1 == t2) && this.preloadSlide(t2), 0 === this.index && 0 === t2 && (this.index = 1), this.updateNavigationClasses(), a2 = this.slidesContainer.querySelectorAll(".gslide")[t2], h2 = this.getSlidePlayerInstance(t2), s2.slideNode = a2;
          }
          this.trigger("slide_inserted", {
            index: t2,
            slide: a2,
            slideNode: a2,
            slideConfig: n2,
            slideIndex: t2,
            trigger: null,
            player: h2
          }), C(this.settings.slideInserted) && this.settings.slideInserted({
            index: t2,
            slide: a2,
            player: h2
          });
        }
      }, {
        key: "removeSlide",
        value: function() {
          var e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1;
          if (e2 < 0 || e2 > this.elements.length - 1) return false;
          var t2 = this.slidesContainer && this.slidesContainer.querySelectorAll(".gslide")[e2];
          t2 && (this.getActiveSlideIndex() == e2 && (e2 == this.elements.length - 1 ? this.prevSlide() : this.nextSlide()), t2.parentNode.removeChild(t2)), this.elements.splice(e2, 1), this.trigger("slide_removed", e2), C(this.settings.slideRemoved) && this.settings.slideRemoved(e2);
        }
      }, {
        key: "slideAnimateIn",
        value: function(e2, t2) {
          var i2 = this, n2 = e2.querySelector(".gslide-media"), s2 = e2.querySelector(".gslide-description"), l2 = {
            index: this.prevActiveSlideIndex,
            slide: this.prevActiveSlide,
            slideNode: this.prevActiveSlide,
            slideIndex: this.prevActiveSlide,
            slideConfig: O(this.prevActiveSlideIndex) ? null : this.elements[this.prevActiveSlideIndex].slideConfig,
            trigger: O(this.prevActiveSlideIndex) ? null : this.elements[this.prevActiveSlideIndex].node,
            player: this.getSlidePlayerInstance(this.prevActiveSlideIndex)
          }, o2 = {
            index: this.index,
            slide: this.activeSlide,
            slideNode: this.activeSlide,
            slideConfig: this.elements[this.index].slideConfig,
            slideIndex: this.index,
            trigger: this.elements[this.index].node,
            player: this.getSlidePlayerInstance(this.index)
          };
          if (n2.offsetWidth > 0 && s2 && (m(s2), s2.style.display = ""), c(e2, this.effectsClasses), t2) v(e2, this.settings.cssEfects[this.settings.openEffect].in, function() {
            i2.settings.autoplayVideos && i2.slidePlayerPlay(e2), i2.trigger("slide_changed", {
              prev: l2,
              current: o2
            }), C(i2.settings.afterSlideChange) && i2.settings.afterSlideChange.apply(i2, [l2, o2]);
          });
          else {
            var r2 = this.settings.slideEffect, a2 = "none" !== r2 ? this.settings.cssEfects[r2].in : r2;
            this.prevActiveSlideIndex > this.index && "slide" == this.settings.slideEffect && (a2 = this.settings.cssEfects.slideBack.in), v(e2, a2, function() {
              i2.settings.autoplayVideos && i2.slidePlayerPlay(e2), i2.trigger("slide_changed", {
                prev: l2,
                current: o2
              }), C(i2.settings.afterSlideChange) && i2.settings.afterSlideChange.apply(i2, [l2, o2]);
            });
          }
          setTimeout(function() {
            i2.resize(e2);
          }, 100), d(e2, "current");
        }
      }, {
        key: "slideAnimateOut",
        value: function() {
          if (!this.prevActiveSlide) return false;
          var e2 = this.prevActiveSlide;
          c(e2, this.effectsClasses), d(e2, "prev");
          var t2 = this.settings.slideEffect, i2 = "none" !== t2 ? this.settings.cssEfects[t2].out : t2;
          this.slidePlayerPause(e2), this.trigger("slide_before_change", {
            prev: {
              index: this.prevActiveSlideIndex,
              slide: this.prevActiveSlide,
              slideNode: this.prevActiveSlide,
              slideIndex: this.prevActiveSlideIndex,
              slideConfig: O(this.prevActiveSlideIndex) ? null : this.elements[this.prevActiveSlideIndex].slideConfig,
              trigger: O(this.prevActiveSlideIndex) ? null : this.elements[this.prevActiveSlideIndex].node,
              player: this.getSlidePlayerInstance(this.prevActiveSlideIndex)
            },
            current: {
              index: this.index,
              slide: this.activeSlide,
              slideNode: this.activeSlide,
              slideIndex: this.index,
              slideConfig: this.elements[this.index].slideConfig,
              trigger: this.elements[this.index].node,
              player: this.getSlidePlayerInstance(this.index)
            }
          }), C(this.settings.beforeSlideChange) && this.settings.beforeSlideChange.apply(this, [{
            index: this.prevActiveSlideIndex,
            slide: this.prevActiveSlide,
            player: this.getSlidePlayerInstance(this.prevActiveSlideIndex)
          }, {
            index: this.index,
            slide: this.activeSlide,
            player: this.getSlidePlayerInstance(this.index)
          }]), this.prevActiveSlideIndex > this.index && "slide" == this.settings.slideEffect && (i2 = this.settings.cssEfects.slideBack.out), v(e2, i2, function() {
            var t3 = e2.querySelector(".ginner-container"), i3 = e2.querySelector(".gslide-media"), n2 = e2.querySelector(".gslide-description");
            t3.style.transform = "", i3.style.transform = "", c(i3, "greset"), i3.style.opacity = "", n2 && (n2.style.opacity = ""), c(e2, "prev");
          });
        }
      }, {
        key: "getAllPlayers",
        value: function() {
          return this.videoPlayers;
        }
      }, {
        key: "getSlidePlayerInstance",
        value: function(e2) {
          var t2 = "gvideo" + e2, i2 = this.getAllPlayers();
          return !(!P(i2, t2) || !i2[t2]) && i2[t2];
        }
      }, {
        key: "stopSlideVideo",
        value: function(e2) {
          if (E(e2)) {
            var t2 = e2.querySelector(".gvideo-wrapper");
            t2 && (e2 = t2.getAttribute("data-index"));
          }
          console.log("stopSlideVideo is deprecated, use slidePlayerPause");
          var i2 = this.getSlidePlayerInstance(e2);
          i2 && i2.playing && i2.pause();
        }
      }, {
        key: "slidePlayerPause",
        value: function(e2) {
          if (E(e2)) {
            var t2 = e2.querySelector(".gvideo-wrapper");
            t2 && (e2 = t2.getAttribute("data-index"));
          }
          var i2 = this.getSlidePlayerInstance(e2);
          i2 && i2.playing && i2.pause();
        }
      }, {
        key: "playSlideVideo",
        value: function(e2) {
          if (E(e2)) {
            var t2 = e2.querySelector(".gvideo-wrapper");
            t2 && (e2 = t2.getAttribute("data-index"));
          }
          console.log("playSlideVideo is deprecated, use slidePlayerPlay");
          var i2 = this.getSlidePlayerInstance(e2);
          i2 && !i2.playing && i2.play();
        }
      }, {
        key: "slidePlayerPlay",
        value: function(e2) {
          var t2;
          if (!K || null !== (t2 = this.settings.plyr.config) && void 0 !== t2 && t2.muted) {
            if (E(e2)) {
              var i2 = e2.querySelector(".gvideo-wrapper");
              i2 && (e2 = i2.getAttribute("data-index"));
            }
            var n2 = this.getSlidePlayerInstance(e2);
            n2 && !n2.playing && (n2.play(), this.settings.autofocusVideos && n2.elements.container.focus());
          }
        }
      }, {
        key: "setElements",
        value: function(e2) {
          var t2 = this;
          this.settings.elements = false;
          var i2 = [];
          e2 && e2.length && r(e2, function(e3, n2) {
            var s2 = new V(e3, t2, n2), l2 = s2.getConfig(), r2 = o({}, l2);
            r2.slideConfig = l2, r2.instance = s2, r2.index = n2, i2.push(r2);
          }), this.elements = i2, this.lightboxOpen && (this.slidesContainer.innerHTML = "", this.elements.length && (r(this.elements, function() {
            var e3 = y(t2.settings.slideHTML);
            t2.slidesContainer.appendChild(e3);
          }), this.showSlide(0, true)));
        }
      }, {
        key: "getElementIndex",
        value: function(e2) {
          var t2 = false;
          return r(this.elements, function(i2, n2) {
            if (P(i2, "node") && i2.node == e2) return t2 = n2, true;
          }), t2;
        }
      }, {
        key: "getElements",
        value: function() {
          var e2 = this, t2 = [];
          this.elements = this.elements ? this.elements : [], !O(this.settings.elements) && A(this.settings.elements) && this.settings.elements.length && r(this.settings.elements, function(i3, n2) {
            var s2 = new V(i3, e2, n2), l2 = s2.getConfig(), r2 = o({}, l2);
            r2.node = false, r2.index = n2, r2.instance = s2, r2.slideConfig = l2, t2.push(r2);
          });
          var i2 = false;
          return this.getSelector() && (i2 = document.querySelectorAll(this.getSelector())), i2 ? (r(i2, function(i3, n2) {
            var s2 = new V(i3, e2, n2), l2 = s2.getConfig(), r2 = o({}, l2);
            r2.node = i3, r2.index = n2, r2.instance = s2, r2.slideConfig = l2, r2.gallery = i3.getAttribute("data-gallery"), t2.push(r2);
          }), t2) : t2;
        }
      }, {
        key: "getGalleryElements",
        value: function(e2, t2) {
          return e2.filter(function(e3) {
            return e3.gallery == t2;
          });
        }
      }, {
        key: "getSelector",
        value: function() {
          return !this.settings.elements && (this.settings.selector && "data-" == this.settings.selector.substring(0, 5) ? "*[".concat(this.settings.selector, "]") : this.settings.selector);
        }
      }, {
        key: "getActiveSlide",
        value: function() {
          return this.slidesContainer.querySelectorAll(".gslide")[this.index];
        }
      }, {
        key: "getActiveSlideIndex",
        value: function() {
          return this.index;
        }
      }, {
        key: "getAnimationClasses",
        value: function() {
          var e2 = [];
          for (var t2 in this.settings.cssEfects) if (this.settings.cssEfects.hasOwnProperty(t2)) {
            var i2 = this.settings.cssEfects[t2];
            e2.push("g".concat(i2.in)), e2.push("g".concat(i2.out));
          }
          return e2.join(" ");
        }
      }, {
        key: "build",
        value: function() {
          var e2 = this;
          if (this.built) return false;
          var t2 = document.body.childNodes, i2 = [];
          r(t2, function(e3) {
            e3.parentNode == document.body && "#" !== e3.nodeName.charAt(0) && e3.hasAttribute && !e3.hasAttribute("aria-hidden") && (i2.push(e3), e3.setAttribute("aria-hidden", "true"));
          });
          var n2 = P(this.settings.svg, "next") ? this.settings.svg.next : "", s2 = P(this.settings.svg, "prev") ? this.settings.svg.prev : "", l2 = P(this.settings.svg, "close") ? this.settings.svg.close : "", o2 = this.settings.lightboxHTML;
          o2 = y(o2 = (o2 = (o2 = o2.replace(/{nextSVG}/g, n2)).replace(/{prevSVG}/g, s2)).replace(/{closeSVG}/g, l2)), document.body.appendChild(o2);
          var a2 = document.getElementById("glightbox-body");
          this.modal = a2;
          var c2 = a2.querySelector(".gclose");
          this.prevButton = a2.querySelector(".gprev"), this.nextButton = a2.querySelector(".gnext"), this.overlay = a2.querySelector(".goverlay"), this.loader = a2.querySelector(".gloader"), this.slidesContainer = document.getElementById("glightbox-slider"), this.bodyHiddenChildElms = i2, this.events = {}, d(this.modal, "glightbox-" + this.settings.skin), this.settings.closeButton && c2 && (this.events.close = h("click", {
            onElement: c2,
            withCallback: function(t3, i3) {
              t3.preventDefault(), e2.close();
            }
          })), c2 && !this.settings.closeButton && c2.parentNode.removeChild(c2), this.nextButton && (this.events.next = h("click", {
            onElement: this.nextButton,
            withCallback: function(t3, i3) {
              t3.preventDefault(), e2.nextSlide();
            }
          })), this.prevButton && (this.events.prev = h("click", {
            onElement: this.prevButton,
            withCallback: function(t3, i3) {
              t3.preventDefault(), e2.prevSlide();
            }
          })), this.settings.closeOnOutsideClick && (this.events.outClose = h("click", {
            onElement: a2,
            withCallback: function(t3, i3) {
              e2.preventOutsideClick || u(document.body, "glightbox-mobile") || g(t3.target, ".ginner-container") || g(t3.target, ".gbtn") || u(t3.target, "gnext") || u(t3.target, "gprev") || e2.close();
            }
          })), r(this.elements, function(t3, i3) {
            e2.slidesContainer.appendChild(t3.instance.create()), t3.slideNode = e2.slidesContainer.querySelectorAll(".gslide")[i3];
          }), Q && d(document.body, "glightbox-touch"), this.events.resize = h("resize", {
            onElement: window,
            withCallback: function() {
              e2.resize();
            }
          }), this.built = true;
        }
      }, {
        key: "resize",
        value: function() {
          var e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
          if ((e2 = e2 || this.activeSlide) && !u(e2, "zoomed")) {
            var t2 = x(), i2 = e2.querySelector(".gvideo-wrapper"), n2 = e2.querySelector(".gslide-image"), s2 = this.slideDescription, l2 = t2.width, o2 = t2.height;
            if (l2 <= 768 ? d(document.body, "glightbox-mobile") : c(document.body, "glightbox-mobile"), i2 || n2) {
              var r2 = false;
              if (s2 && (u(s2, "description-bottom") || u(s2, "description-top")) && !u(s2, "gabsolute") && (r2 = true), n2) {
                if (l2 <= 768) n2.querySelector("img");
                else if (r2) {
                  var a2, h2, g2 = s2.offsetHeight, v2 = n2.querySelector("img"), f2 = null === (a2 = this.elements[this.index]) || void 0 === a2 ? void 0 : a2.node, p2 = "100vh";
                  f2 && (p2 = null !== (h2 = f2.getAttribute("data-height")) && void 0 !== h2 ? h2 : p2), v2.setAttribute("style", "max-height: calc(".concat(p2, " - ").concat(g2, "px)")), s2.setAttribute("style", "max-width: ".concat(v2.offsetWidth, "px;"));
                }
              }
              if (i2) {
                var m2 = P(this.settings.plyr.config, "ratio") ? this.settings.plyr.config.ratio : "";
                if (!m2) {
                  var y2 = i2.clientWidth, b2 = i2.clientHeight, S2 = y2 / b2;
                  m2 = "".concat(y2 / S2, ":").concat(b2 / S2);
                }
                var w2 = m2.split(":"), T2 = this.settings.videosWidth, C2 = this.settings.videosWidth, k2 = (C2 = z(T2) || -1 !== T2.indexOf("px") ? parseInt(T2) : -1 !== T2.indexOf("vw") ? l2 * parseInt(T2) / 100 : -1 !== T2.indexOf("vh") ? o2 * parseInt(T2) / 100 : -1 !== T2.indexOf("%") ? l2 * parseInt(T2) / 100 : parseInt(i2.clientWidth)) / (parseInt(w2[0]) / parseInt(w2[1]));
                if (k2 = Math.floor(k2), r2 && (o2 -= s2.offsetHeight), C2 > l2 || k2 > o2 || o2 < k2 && l2 > C2) {
                  var E2 = i2.offsetWidth, A2 = i2.offsetHeight, L2 = o2 / A2, I2 = {
                    width: E2 * L2,
                    height: A2 * L2
                  };
                  i2.parentNode.setAttribute("style", "max-width: ".concat(I2.width, "px")), r2 && s2.setAttribute("style", "max-width: ".concat(I2.width, "px;"));
                } else i2.parentNode.style.maxWidth = "".concat(T2), r2 && s2.setAttribute("style", "max-width: ".concat(T2, ";"));
              }
            }
          }
        }
      }, {
        key: "reload",
        value: function() {
          this.init();
        }
      }, {
        key: "updateNavigationClasses",
        value: function() {
          var e2 = this.loop();
          c(this.nextButton, "disabled"), c(this.prevButton, "disabled"), 0 == this.index && this.elements.length - 1 == 0 ? (d(this.prevButton, "disabled"), d(this.nextButton, "disabled")) : 0 !== this.index || e2 ? this.index !== this.elements.length - 1 || e2 || d(this.nextButton, "disabled") : d(this.prevButton, "disabled");
        }
      }, {
        key: "loop",
        value: function() {
          var e2 = P(this.settings, "loopAtEnd") ? this.settings.loopAtEnd : null;
          return e2 = P(this.settings, "loop") ? this.settings.loop : e2, e2;
        }
      }, {
        key: "close",
        value: function() {
          var e2 = this;
          if (!this.lightboxOpen) {
            if (this.events) {
              for (var t2 in this.events) this.events.hasOwnProperty(t2) && this.events[t2].destroy();
              this.events = null;
            }
            return false;
          }
          if (this.closing) return false;
          this.closing = true, this.slidePlayerPause(this.activeSlide), this.fullElementsList && (this.elements = this.fullElementsList), this.bodyHiddenChildElms.length && r(this.bodyHiddenChildElms, function(e3) {
            e3.removeAttribute("aria-hidden");
          }), d(this.modal, "glightbox-closing"), v(this.overlay, "none" == this.settings.openEffect ? "none" : this.settings.cssEfects.fade.out), v(this.activeSlide, this.settings.cssEfects[this.settings.closeEffect].out, function() {
            if (e2.activeSlide = null, e2.prevActiveSlideIndex = null, e2.prevActiveSlide = null, e2.built = false, e2.events) {
              for (var t3 in e2.events) e2.events.hasOwnProperty(t3) && e2.events[t3].destroy();
              e2.events = null;
            }
            var i2 = document.body;
            c(ee, "glightbox-open"), c(i2, "glightbox-open touching gdesc-open glightbox-touch glightbox-mobile gscrollbar-fixer"), e2.modal.parentNode.removeChild(e2.modal), e2.trigger("close"), C(e2.settings.onClose) && e2.settings.onClose();
            var n2 = document.querySelector(".gcss-styles");
            n2 && n2.parentNode.removeChild(n2), e2.lightboxOpen = false, e2.closing = null;
          });
        }
      }, {
        key: "destroy",
        value: function() {
          this.close(), this.clearAllEvents(), this.baseEvents && this.baseEvents.destroy();
        }
      }, {
        key: "on",
        value: function(e2, t2) {
          var i2 = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
          if (!e2 || !C(t2)) throw new TypeError("Event name and callback must be defined");
          this.apiEvents.push({
            evt: e2,
            once: i2,
            callback: t2
          });
        }
      }, {
        key: "once",
        value: function(e2, t2) {
          this.on(e2, t2, true);
        }
      }, {
        key: "trigger",
        value: function(e2) {
          var t2 = this, i2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, n2 = [];
          r(this.apiEvents, function(t3, s2) {
            var l2 = t3.evt, o2 = t3.once, r2 = t3.callback;
            l2 == e2 && (r2(i2), o2 && n2.push(s2));
          }), n2.length && r(n2, function(e3) {
            return t2.apiEvents.splice(e3, 1);
          });
        }
      }, {
        key: "clearAllEvents",
        value: function() {
          this.apiEvents.splice(0, this.apiEvents.length);
        }
      }, {
        key: "version",
        value: function() {
          return "3.3.1";
        }
      }]);
      return function() {
        var e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t2 = new ie(e2);
        return t2.init(), t2;
      };
    });
  }
});
export default require_glightbox_min();
//# sourceMappingURL=glightbox.js.map
